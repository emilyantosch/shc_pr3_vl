package student.info.system;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

//This class is used to access the database. Currently we are using dummy values,
// which are access by using "dummy" as the database connection URL.
public class DatabaseAccessor {

	private Connection _con = null;

	public DatabaseAccessor(String dbUrl, String username, String password) {

		if (dbUrl.equals("dummy")) {
			// when we use "dummy" Entries without DB connection
		} else {
			// the real deal, connecting to the database
			try {
				_con = DriverManager.getConnection(dbUrl, username, password);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	// Task 1.3
	public Student[] getAllStudents() {
		// TODO implement SQL Query to get all students and
		// store these Student in the variable result.
		Student[] result = new Student[] { new Student("John", "Doe", 1, "Information Engineering") };
		return result;
	}

	// Task 1.4
	public Attempt[] getAttemptsForStudent(Student student) {
		// TODO write a Query that gets all the attempts a student has in the database
		// and
		// store these Attempts int the variable result
		Attempt[] result = new Attempt[] { new Attempt(2022, 0, "SC 1", 15) };
		return result;
	}
}
