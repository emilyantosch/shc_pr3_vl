module StudentInformationSystem {
	requires java.desktop;
	requires java.sql;
}